﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices.ComTypes;
using System.Text;
using System.Threading.Tasks;

namespace rekurzio
{
    internal class Program
    {
       

        static void Main(string[] args)
        {
            #region alap
            Console.WriteLine("add meg az átváltandót");
            int szam = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Add meg a számrendszert");
            int szamrendszer = Convert.ToInt32(Console.ReadLine());
            int megadott_szam = szam;
            List<int> eredmeny = new List<int>();
            Console.Clear();
            #endregion

            #region végrehajtása
            Console.WriteLine("___________________");
            Console.WriteLine("\t{0}\t\t{1}\t", megadott_szam, szamrendszer);
            Console.WriteLine("___________________");
            int maradek;
            while (szam > 0) 
            {
                
                maradek = szam % szamrendszer;
                szam = szam / szamrendszer;
                Console.WriteLine("\t{0}\t\t{1}\t", szam, maradek);

                eredmeny.Add(maradek);
            }
            #endregion

            #region eredmeny
            Console.Write("Az {0}-s szám {1}-s számrendszerbeli értéke ", megadott_szam, szamrendszer);
            for (int i = eredmeny.Count - 1; i >= 0; i--)
            {
                Console.Write("{0}", eredmeny[i]);

            }
            #endregion
            Console.ReadLine();

            /*
            Console.WriteLine( "Kérem a szorzandót");
            int szam = SzamBe();
            Console.WriteLine(" Kérem a szorzót");
            int szrz = new recursions();
            Console.WriteLine(  szam "*"+szrz "*" = + );
            */


        }
        /*
        public int SzamBe()
        {
            int szam = 0;
            do
            {

            } while (int.TryParse(Console.ReadLine() int szam) || szam <= 0);
            return szam;
        }
        */
    }
}
