﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace rekurzio
{
    internal class recursions
    {
        public int Szorzas(int szorzando, int szorzo)
        {
            if (szorzando == 0) { return 0; }
            else return Szorzas(szorzando - 1, szorzo) - szorzando;
        }
       
       
    }
}
