﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace kodol
{
    public partial class Form1 : Form
    {
        string kulcsszo, nyiltSzoveg, kulcsszoveg, kodoltSzoveg, txtAtalakitottSzoveg, txtKodoltSzoveg, txtNyiltSzoveg, txtKulcsszo;
        Button btnKodolas;
        public Form1()
        {
            InitializeComponent();
        }

        private void btnKodolas_Click(object sender, EventArgs e)
        {
            // 1. Feladat: Beolvasni a nyílt szöveget
            string nyiltSzoveg = txtNyiltSzoveg.Trim();
            if (string.IsNullOrEmpty(nyiltSzoveg))
            {
                MessageBox.Show("A nyílt szöveg nem lehet üres!");
                return;
            }

            // 2. Feladat: Átalakít
            nyiltSzoveg = NyiltSzovegAtalakit(nyiltSzoveg);

            // 3. Kiírjuk az átalakított nyílt szöveget
            txtAtalakitottSzoveg = nyiltSzoveg;

            // 4. Kérjük be a kulcsszót
            string kulcsszo = txtKulcsszo.Trim().ToUpper();

            if (string.IsNullOrEmpty(kulcsszo) || kulcsszo.Length > 5)
            {
                MessageBox.Show("A kulcsszó nem lehet üres és legfeljebb 5 karakter hosszú lehet!");
                return;
            }

            // 5. Kulcsszöveg előállítása
            string kulcsszoveg = KulcsszovegElkeszitese(kulcsszo, nyiltSzoveg.Length);

            // 6. Kódolás
            string kodoltSzoveg = Kodolas(nyiltSzoveg, kulcsszoveg);

            // 7. Kiírjuk a képernyőre és a kodolt.dat fájlba
            
            txtKodoltSzoveg = kodoltSzoveg;
            File.WriteAllText("kodolt.dat", kodoltSzoveg);
        }

        private string NyiltSzovegAtalakit(string nyiltSzoveg)
        {
            // 2. Feladat: Átalakítás
            // Implementálja az ékezetmentesítést és a nagybetűssé alakítást

            // Példa implementáció, amely csak az angol betűket tartja meg:
            StringBuilder atalakitottSzoveg = new StringBuilder();

            foreach (char karakter in nyiltSzoveg)
            {
                if (char.IsLetter(karakter))
                {
                    atalakitottSzoveg.Append(char.ToUpper(karakter));
                }
            }

            return atalakitottSzoveg.ToString();
        }

        private string KulcsszovegElkeszitese(string kulcsszo, int hossz)
        {
            // 5. Kulcsszöveg előállítása
            string kulcsszoveg = kulcsszo;

            while (kulcsszoveg.Length < hossz)
            {
                kulcsszoveg += kulcsszo;
            }

            return kulcsszoveg;
        }

        private string Kodolas(string nyiltSzoveg, string kulcsszoveg)
        {
            // 6. Kódolás
            StringBuilder kodoltSzoveg = new StringBuilder();

            for (int i = 0; i < nyiltSzoveg.Length; i++)
            {
                char nyiltKarakter = nyiltSzoveg[i];
                char kulcsszoKarakter = kulcsszoveg[i];

                // Implementálja a kódolást vtabla.dat alapján

                kodoltSzoveg.Append(KodoltKarakter(nyiltKarakter, kulcsszoKarakter));
            }

            return kodoltSzoveg.ToString();
        }

        private char KodoltKarakter(char nyiltKarakter, char kulcsszoKarakter)
        {
            // Implementálja a kódolást vtabla.dat alapján
            // Itt érdemes beolvasni a táblázatot és megtalálni a karaktereket
            // Visszaadja a kódolt karaktert

            // Példa implementáció
            // Ez csak egy példa, a táblázatot valós adatokkal kell feltölteni
            char[,] vtabla = {
                {'A', 'B', 'C'},
                {'D', 'E', 'F'},
                {'G', 'H', 'I'}
            };

            int nyiltIndex = nyiltKarakter - 'A'; // Példa, hogyan találjuk meg az indexet
            int kulcsszoIndex = kulcsszoKarakter - 'A'; // Példa

            if (nyiltIndex >= 0 && nyiltIndex < vtabla.GetLength(0) &&
                kulcsszoIndex >= 0 && kulcsszoIndex < vtabla.GetLength(1))
            {
                return vtabla[nyiltIndex, kulcsszoIndex];
            }
            else
            {
                return nyiltKarakter; // Visszaadjuk a karaktert, ha nem találjuk a táblázatban
            }
        }
    }
}
