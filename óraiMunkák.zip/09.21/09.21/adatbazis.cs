﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using MySql.Data;
using System.Web;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Runtime.InteropServices.WindowsRuntime;

namespace _09._21
{
    internal class adatbazis
    {
        string kapcs_string;
        MySqlConnection kapcsolat;
        MySqlCommand parancs;
        string parancs_string;
        MySqlDataAdapter adapter;
        public adatbazis(string k)
        {
            kapcs_string = k;
        }

        public adatbazis(string S, string D, string L, string P)
        {
            S=S.Trim();
            D=D.Trim();
            L =L.Trim();
            P=P.Trim();

            if (S.Last() == ';') S = S.Remove(S.Length - 1, 1);
            if (D.Last() == ';') D = D.Remove(D.Length - 1, 1);
            if (L.Last() == ';') L = L.Remove(L.Length - 1, 1);
            if (P.Last() == ';') P = P.Remove(P.Length - 1, 1);

            kapcs_string = S + ";"+ D + ";"+L + ";"+P + ";";
        }

        private bool megnyitas()
        {
            try
            {
                kapcsolat = new MySqlConnection(kapcs_string);
                kapcsolat.Open();
                return true;
            }
            catch 
            {

                return false;
            }
        }
        private bool bezaras()
        {
            try
            {
                kapcsolat.Close();
                return true;
            }
            catch 
            {
                return false;
            }
        }
        public string SzamLekerdezes(string lekerdezes)
        {
            bezaras();
            if (megnyitas())
            {
                try
                {
                    parancs = new MySqlCommand(lekerdezes, kapcsolat);
                    return parancs.ExecuteScalar().ToString();
                }
                catch 
                {
                    return "Hiba ";

                }
            }
            else
            {
                    return "Hiba ";

                }
        }
        public List<string>ListaLekerdezes(string lekerdezes)
        {
            bezaras();
            List<string> L = new List<string>();
            if (megnyitas())
            {
                try
                {
                    parancs = new MySqlCommand(lekerdezes , kapcsolat);
                    MySqlDataReader olvas = parancs.ExecuteReader();
                    while (olvas.Read())
                    {
                        L.Add(olvas[0].ToString());
                    }
                }
                catch ( Exception ex)
                {

                    L.Add("Hiba");
                    L.Add(ex.ToString());
                }
            }
            else
            {
                L.Add("hiba");
            }
            return L;
        }
        public bool DdlDml(string lekerdezes)
        {
            bezaras();
            if (megnyitas())
            {
                try
                {
                    parancs = new MySqlCommand();
                    parancs.CommandText = lekerdezes;
                    parancs.Connection = kapcsolat;
                    parancs.ExecuteNonQuery();
                    bezaras();
                    return true;
                    
                }
                catch 
                {
                    return false;
                    
                }
            }
            return false;
        }
        public DataSet TablazatLekerdezes(string lekerdezes)
        {
            bezaras();
            DataSet adatok = new DataSet();
            if (megnyitas())
            {
                try
                {
                    adapter = new MySqlDataAdapter();
                    adapter.SelectCommand = new MySqlCommand(lekerdezes, kapcsolat);
                    adapter.Fill(adatok);
                    return adatok;
                }
                catch 
                {

                   
                }
            }
            return adatok;
        }
    }
}
