﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _09._21
{
    public partial class Form1 : Form
    {
        ListBox LB;
        DataGridView DGV;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

            adatbazis DB = new adatbazis("server=localhost;database=partnerek;user=root;password=;");
            Text = DB.SzamLekerdezes("SELECT COUNT(*) FROM aru");
            /* LB = new ListBox()
             {
                 Parent = this,
                 Location = new Point(20, 20),
                 Size = new Size(300, this.Height - 40),
                 Font = new Font("Times", 13f),
             };
             LB.DataSource = DB.ListaLekerdezes("SELECT nev FROM kontakt");

             DB.DdlDml("INSERT INTO ceg VALUES (6,'Maharet KFT')");*/

            DGV = new DataGridView()
            {
                Parent = this,
                Location = new Point(20, 20),
                Font = new Font("Times", 14f),
                Size = new Size(this.Width - 40, this.Height - 70),
                RowHeadersVisible = false,
            };

            DGV.DataSource = DB.TablazatLekerdezes("SELECT * FROM aru;").Tables[0];


            DGV.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
            DGV.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
            DGV.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            DGV.AllowUserToAddRows = false;
            DGV.AutoSize = true;
            int magassag = DGV.Height -40;
            int szelesseg = DGV.Width - 40;
            DGV.AutoSize = false;
            DGV.Size = new Size(magassag, szelesseg);
            
        }
    }
}
