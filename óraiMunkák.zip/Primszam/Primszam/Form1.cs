﻿
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Console;
using MySql.Data.MySqlClient;

namespace Primszam
{

    public partial class Form1 : Form
    {
        private MySqlConnection dbConnection;
        private Button findPrimesButton, checkPrimeButton, addPrimeButton, deletePrimeButton;
        private TextBox searchTextBox, addPrimeTextBox;
       
       
        public Form1()
        {
            InitializeComponent();
            string connectionString = "Server=127.0.0.1;Database=primesdb;Uid=root;Pwd=;";

            dbConnection = new MySqlConnection(connectionString);

            findPrimesButton = new Button();
            findPrimesButton.Text = "Prímek keresése (100-asával)";
            findPrimesButton.Width = 200;
            findPrimesButton.Height = 30;
            findPrimesButton.Location = new System.Drawing.Point(10, 10);
            findPrimesButton.Click += new EventHandler(FindPrimesButton_Click);
            this.Controls.Add(findPrimesButton);

           
            searchTextBox = new TextBox();
            searchTextBox.Width = 200;
            searchTextBox.Location = new System.Drawing.Point(130, 80);
            this.Controls.Add(searchTextBox);

            checkPrimeButton = new Button();
            checkPrimeButton.Text = "Ellenőrzés";
            checkPrimeButton.Width = 100;
            checkPrimeButton.Height = 30;
            checkPrimeButton.Location = new System.Drawing.Point(10, 80);
            checkPrimeButton.Click += new EventHandler(CheckPrimeButton_Click);
            this.Controls.Add(checkPrimeButton);

            addPrimeButton = new Button();
            addPrimeButton.Text = "Prímek hozzáadása";
            addPrimeButton.Width = 150;
            addPrimeButton.Height = 30;
            addPrimeButton.Location = new System.Drawing.Point(10, 130);
            addPrimeButton.Click += new EventHandler(AddPrimeButton_Click);
            this.Controls.Add(addPrimeButton);

            addPrimeTextBox = new TextBox();
            addPrimeTextBox.Width = 150;
            addPrimeTextBox.Location = new System.Drawing.Point(170, 130);
            this.Controls.Add(addPrimeTextBox);
            
            deletePrimeButton = new Button();
            deletePrimeButton.Text = "Prímek törlése";
            deletePrimeButton.Width = 150;
            deletePrimeButton.Height = 30;
            deletePrimeButton.Location = new System.Drawing.Point(10, 180);
            deletePrimeButton.Click += new EventHandler(DeletePrimesButton_Click);
            this.Controls.Add(deletePrimeButton);
        }
        private bool IsPrimeFast(int number)
        {
            if (number <= 1)
                return false;
            if (number <= 3)
                return true;
            if (number % 2 == 0 || number % 3 == 0)
                return false;

            for (int i = 5; i * i <= number; i += 6)
            {
                if (number % i == 0 || number % (i + 2) == 0)
                    return false;
            }

            return true;
        }

        private void AddPrimeButton_Click(object sender, EventArgs e)
        {
            

            if (int.TryParse(addPrimeTextBox.Text, out int numberToAdd))
            {
               
                if (IsPrimeFast(numberToAdd))
                {
                  
                    dbConnection.Open();
                    MySqlCommand insertCmd = new MySqlCommand("INSERT INTO Primes (value) VALUES (@value)", dbConnection);
                    insertCmd.Parameters.AddWithValue("@value", numberToAdd);
                    insertCmd.ExecuteNonQuery();
                    dbConnection.Close();

                  
                    MessageBox.Show($"{numberToAdd} prímszám sikeresen hozzáadva az adatbázishoz.");
                }
                else
                {
                    MessageBox.Show($"{numberToAdd} nem prímszám. Csak prímszámokat lehet hozzáadni.");
                }
            }
            else
            {
                MessageBox.Show("Érvénytelen bemenet. Kérlek adj meg egy érvényes számot.");
            }
        }


        private void FindPrimesButton_Click(object sender, EventArgs e)
        {
            
            try
            {
                dbConnection.Open();
               
            }
            catch (Exception )
            {
                MessageBox.Show($"Hiba az adatbázis kapcsolat megnyitása során: ");
            }

            MySqlCommand maxCmd = new MySqlCommand("SELECT MAX(value) FROM primes", dbConnection);
            object result = maxCmd.ExecuteScalar();
            int lastPrime = (result != DBNull.Value) ? Convert.ToInt32(result) : 1;

            for (int i = lastPrime + 1; i <= lastPrime + 100; i++)
            {
                if (IsPrimeFast(i))
                {
                    MySqlCommand insertCmd = new MySqlCommand("INSERT INTO primes (value) VALUES (@value)", dbConnection);
                    insertCmd.Parameters.AddWithValue("@value", i);
                    insertCmd.ExecuteNonQuery();
                }
            }

            dbConnection.Close();
        }

            private void CheckPrimeButton_Click(object sender, EventArgs e)
        {
            int numberToCheck;
            if (int.TryParse(searchTextBox.Text, out numberToCheck))
            {
                bool isPrime = IsPrimeFast(numberToCheck);

                if (isPrime)
                {
                    MessageBox.Show($"{numberToCheck} prím szám.");
                }
                else
                {
                    MessageBox.Show($"{numberToCheck} nem prím szám.");
                }
            }
            else
            {
                MessageBox.Show("Érvénytelen bemenet. Kérlek adj meg egy érvényes számot.");
            }

        }
        private void DeletePrimesButton_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Biztosan törölni szeretnéd az összes prímszámot az adatbázisból?", "Prímek törlése", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                dbConnection.Open();
                MySqlCommand deleteCmd = new MySqlCommand("DELETE FROM Primes", dbConnection);
                deleteCmd.ExecuteNonQuery();
                dbConnection.Close();

                MessageBox.Show("Az összes prímszám sikeresen törölve.");
            }
        }

    }
}


