﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace torpedo
{
    public partial class Form1 : Form
    {
        private const int rácsMérete = 10;
        private const int cellaMérete = 40;
        private const int margó = 40;

        private Button[,] rácsGombok = new Button[rácsMérete, rácsMérete];
        private bool[,] hajóRács = new bool[rácsMérete, rácsMérete];
        private Dictionary<string, int> hajóMéretek = new Dictionary<string, int>
        {
            {"1-es hajó", 1},
            {"2-es hajó", 2},
            {"3-as hajó", 3},
            {"4-es hajó", 4}
        };
        private int összesTalálat = 0;
        private int összesLövés = 0;

        private Random véletlen = new Random();

        public Form1()
        {
            InitializeComponent();
            RácsInicializálás();
            HajókElhelyezése();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void RácsInicializálás()
        {
            for (int i = 0; i < rácsMérete; i++)
            {
                for (int j = 0; j < rácsMérete; j++)
                {
                    var gomb = new Button
                    {
                        Size = new Size(cellaMérete, cellaMérete),
                        Location = new Point(margó + j * (cellaMérete + margó), margó + i * (cellaMérete + margó)),
                        Tag = new Point(i, j),
                        Font = new Font(FontFamily.GenericSansSerif, 10, FontStyle.Bold),
                    };
                    gomb.Click += RácsGombClick;
                    rácsGombok[i, j] = gomb;
                    Controls.Add(gomb);
                }
            }

            for (int i = 0; i < rácsMérete; i++)
            {
                var címke = new Label
                {
                    Text = (i + 1).ToString(),
                    Location = new Point(margó / 2, margó + i * (cellaMérete + margó)),
                    AutoSize = true,
                    Font = new Font(FontFamily.GenericSansSerif, 10, FontStyle.Bold),
                };
                Controls.Add(címke);
            }

            for (int i = 0; i < rácsMérete; i++)
            {
                var címke = new Label
                {
                    Text = ((char)('A' + i)).ToString(),
                    Location = new Point(margó + i * (cellaMérete + margó), margó / 2),
                    AutoSize = true,
                    Font = new Font(FontFamily.GenericSansSerif, 10, FontStyle.Bold),
                };
                Controls.Add(címke);
            }
        }

        private void HajókElhelyezése()
        {
            foreach (var pár in hajóMéretek)
            {
                HajóElhelyezése(pár.Key, pár.Value);
            }
        }

        private void HajóElhelyezése(string hajóTípus, int méret)
        {
            bool hajóElhelyezve = false;

            while (!hajóElhelyezve)
            {
                bool vízszintes = véletlen.Next(2) == 0;
                int x, y;

                if (vízszintes)
                {
                    x = véletlen.Next(rácsMérete - méret);
                    y = véletlen.Next(rácsMérete);
                }
                else
                {
                    x = véletlen.Next(rácsMérete);
                    y = véletlen.Next(rácsMérete - méret);
                }

                if (HelyezhetőHajó(x, y, méret, vízszintes))
                {

                    bool szomszédos = SzomszédosHajókEllenőrzése(x, y, méret, vízszintes);
                    if (!szomszédos)
                    {
                        for (int i = 0; i < méret; i++)
                        {
                            if (vízszintes)
                                hajóRács[x + i, y] = true;
                            else
                                hajóRács[x, y + i] = true;
                        }
                        hajóElhelyezve = true;
                    }
                }
            }
        }

        private bool SzomszédosHajókEllenőrzése(int x, int y, int méret, bool vízszintes)
        {
            int startX = Math.Max(0, x - 1);
            int startY = Math.Max(0, y - 1);
            int endX = vízszintes ? Math.Min(rácsMérete - 1, x + méret) : Math.Min(rácsMérete - 1, x + 1);
            int endY = vízszintes ? Math.Min(rácsMérete - 1, y + 1) : Math.Min(rácsMérete - 1, y + méret);

            for (int i = startX; i <= endX; i++)
            {
                for (int j = startY; j <= endY; j++)
                {
                    if (hajóRács[i, j])
                        return true;
                }
            }
            return false;
        }

        private bool HelyezhetőHajó(int x, int y, int méret, bool vízszintes)
        {
            if (vízszintes)
            {
                if (x + méret >= rácsMérete)
                    return false;

                for (int i = x; i < x + méret; i++)
                {
                    if (hajóRács[i, y])
                        return false;
                }
            }
            else
            {
                if (y + méret >= rácsMérete)
                    return false;

                for (int i = y; i < y + méret; i++)
                {
                    if (hajóRács[x, i])
                        return false;
                }
            }

            return true;
        }

        private void RácsGombClick(object sender, EventArgs e)
        {
            var gomb = (Button)sender;
            var helyzet = (Point)gomb.Tag;
            int x = helyzet.X;
            int y = helyzet.Y;

            összesLövés++;

            if (hajóRács[x, y])
            {
                gomb.BackColor = Color.Red;
                gomb.Enabled = false;
                összesTalálat++;
                if (összesTalálat == rácsMérete)
                {
                    JátékStatisztikaMegjelenítése();
                    DialogResult eredmény = MessageBox.Show("Gratulálok! Minden hajót elsüllyesztettél!\nSzeretnél új játékot játszani?", "Játék vége", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
                    if (eredmény == DialogResult.Yes)
                    {
                        JátékÚjraindítása();
                    }
                    else
                    {
                        Close();
                    }
                }
            }
            else
            {
                gomb.BackColor = Color.Blue;
                gomb.Enabled = false;

            }
        }

        private void JátékÚjraindítása()
        {
            foreach (var gomb in rácsGombok)
            {
                gomb.BackColor = default(Color);
                gomb.Enabled = true;
            }

            Array.Clear(hajóRács, 0, hajóRács.Length);
            összesTalálat = 0;
            összesLövés = 0;
            HajókElhelyezése();
        }


        private void JátékStatisztikaMegjelenítése()
        {
            string üzenet = $"Gratulálok! Minden hajót elsüllyesztettél {összesLövés} lépésből!";
            MessageBox.Show(üzenet, "Játék vége", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}

