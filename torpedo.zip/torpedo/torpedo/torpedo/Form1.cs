﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace torpedo
{
    public partial class Form1 : Form
    {
        private const int gridSize = 10;
        private const int cellSize = 40;
        private const int margin = 40;

        private Button[,] gridButtons = new Button[gridSize, gridSize];
        private bool[,] shipGrid = new bool[gridSize, gridSize];
        private Dictionary<string, int> shipSizes = new Dictionary<string, int>
        {
            {"1-es hajó", 1},
            {"2-es hajó", 2},
            {"3-as hajó", 3},
            {"4-es hajó", 4}
        };
        private int totalHits = 0;
        private int totalShots = 0; 

        private Random random = new Random();

        public Form1()
        {
            InitializeComponent();
            InitializeGrid();
            PlaceShips();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        private void InitializeGrid()
        {
            for (int i = 0; i < gridSize; i++)
            {
                for (int j = 0; j < gridSize; j++)
                {
                    var button = new Button
                    {
                        Size = new Size(cellSize, cellSize),
                        Location = new Point(margin + j * (cellSize + margin), margin + i * (cellSize + margin)),
                        Tag = new Point(i, j),
                        Font = new Font(FontFamily.GenericSansSerif, 10, FontStyle.Bold),
                    };
                    button.Click += GridButtonClick;
                    gridButtons[i, j] = button;
                    Controls.Add(button);
                }
            }

            for (int i = 0; i < gridSize; i++)
            {
                var label = new Label
                {
                    Text = (i + 1).ToString(),
                    Location = new Point(margin / 2, margin + i * (cellSize + margin)),
                    AutoSize = true,
                    Font = new Font(FontFamily.GenericSansSerif, 10, FontStyle.Bold),
                };
                Controls.Add(label);
            }

            for (int i = 0; i < gridSize; i++)
            {
                var label = new Label
                {
                    Text = ((char)('A' + i)).ToString(),
                    Location = new Point(margin + i * (cellSize + margin), margin / 2),
                    AutoSize = true,
                    Font = new Font(FontFamily.GenericSansSerif, 10, FontStyle.Bold),
                };
                Controls.Add(label);
            }
        }

        private void PlaceShips()
        {
            foreach (var pair in shipSizes)
            {
                PlaceShip(pair.Key, pair.Value);
            }
        }

        private void PlaceShip(string shipType, int size)
        {
            bool shipPlaced = false;

            while (!shipPlaced)
            {
                bool horizontal = random.Next(2) == 0;
                int x, y;

                if (horizontal)
                {
                    x = random.Next(gridSize - size);
                    y = random.Next(gridSize);
                }
                else
                {
                    x = random.Next(gridSize);
                    y = random.Next(gridSize - size);
                }

                if (CanPlaceShip(x, y, size, horizontal))
                {
                   
                    bool adjacent = CheckAdjacentShips(x, y, size, horizontal);
                    if (!adjacent)
                    {
                        for (int i = 0; i < size; i++)
                        {
                            if (horizontal)
                                shipGrid[x + i, y] = true;
                            else
                                shipGrid[x, y + i] = true;
                        }
                        shipPlaced = true;
                    }
                }
            }
        }

        private bool CheckAdjacentShips(int x, int y, int size, bool horizontal)
        {
            int startX = Math.Max(0, x - 1);
            int startY = Math.Max(0, y - 1);
            int endX = horizontal ? Math.Min(gridSize - 1, x + size) : Math.Min(gridSize - 1, x + 1);
            int endY = horizontal ? Math.Min(gridSize - 1, y + 1) : Math.Min(gridSize - 1, y + size);

            for (int i = startX; i <= endX; i++)
            {
                for (int j = startY; j <= endY; j++)
                {
                    if (shipGrid[i, j])
                        return true; 
                }
            }
            return false; 
        }

        private bool CanPlaceShip(int x, int y, int size, bool horizontal)
        {
            if (horizontal)
            {
                if (x + size >= gridSize)
                    return false;

                for (int i = x; i < x + size; i++)
                {
                    if (shipGrid[i, y])
                        return false;
                }
            }
            else
            {
                if (y + size >= gridSize)
                    return false;

                for (int i = y; i < y + size; i++)
                {
                    if (shipGrid[x, i])
                        return false;
                }
            }

            return true;
        }

        private void GridButtonClick(object sender, EventArgs e)
        {
            var button = (Button)sender;
            var location = (Point)button.Tag;
            int x = location.X;
            int y = location.Y;

            totalShots++; 

            if (shipGrid[x, y])
            {
                button.BackColor = Color.Red;
                button.Enabled = false;
                totalHits++;
                if (totalHits == gridSize) 
                {
                    ShowGameStats(); 
                    DialogResult result = MessageBox.Show("Gratulálok! Minden hajót elsüllyesztettél!\nSzeretnél új játékot játszani?", "Játék vége", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
                    if (result == DialogResult.Yes)
                    {
                        ResetGame();
                    }
                    else
                    {
                        Close();
                    }
                }
            }
            else
            {
                button.BackColor = Color.Blue;
                button.Enabled = false;
               
            }
        }

        private void ResetGame()
        {
            foreach (var button in gridButtons)
            {
                button.BackColor = default(Color);
                button.Enabled = true;
            }

            Array.Clear(shipGrid, 0, shipGrid.Length);
            totalHits = 0;
            totalShots = 0;
            PlaceShips();
        }


        private void ShowGameStats()
        {
            string message = $"Gratulálok! Minden hajót elsüllyesztetted {totalShots} lépésből!";
            MessageBox.Show(message, "Játék vége", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}

